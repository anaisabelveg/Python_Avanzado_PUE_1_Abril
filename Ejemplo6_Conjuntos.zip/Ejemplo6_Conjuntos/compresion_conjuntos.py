# crear un conjunto con las letras de la palabra 'abracadabra'
# que no sean a, ni b, n c

# codigo completo

# compresion

