""" 
    solicitar 2 numeros reales al usuario
    aplicar conversion
    mostrar las operaciones aritmeticas
"""

n1 = float(input("Introduce un numero real (1.2): "))
n2 = float(input("Introduce un numero real (1.2): "))

print("Suma:", n1 + n2)
print("Resta:", n1 - n2)
print("Multiplicacion:", n1 * n2)
print("Division:", n1 / n2)
print("Modulo:", n1 % n2)
print("Potencia:", n1 ** n2)
print("Division entera:", n1 // n2)