def datos_trabajador(nombre, estado_civil="Soltero", sueldo=21000) :
    return nombre + " esta " + estado_civil + " gana " + str(sueldo)

print(datos_trabajador("Jose"))
#print(datos_trabajador("Jose", 35000))  # interpreta que 35000 es el estado civil
print(datos_trabajador("Jose", sueldo=35000))
print(datos_trabajador("Jose", estado_civil="Casado"))
print(datos_trabajador("Jose", estado_civil="Casado", sueldo=35000))
print(datos_trabajador("Jose", "Casado", 35000))

# crear una funcion que recibe:
#   - datos como numero variable de argumento
#   - caracter separador opcional, por defecto " | "
#   separador.join(datos)