texto = "bienvenidos al curso de Python"

print(texto)

# Poner primera letra de la frase en mayuscula
print(texto.capitalize())

# Poner la primera letra de cada palabra en mayuscula
print(texto.title())

# frase en mayusculas
print(texto.upper())

# frase en minusculas
print(texto.lower())

# Retornar un valor booleano que indica si la cadena es alfanumerica (letras y numeros)
print("Alfanumerica:", texto.isalnum()) # False porque tiene espacios en blanco
print("Alfanumerica:", "caracola12345".isalnum())  # True

# Retornar un valor booleano que indica si la cadena es alfabetica (letras)
print("Alfabetica:", texto.isalpha()) # False porque tiene espacios en blanco
print("Alfabetica:", "caracola".isalpha())  #True
print("Alfabetica:", "caracola12345".isalpha())  #False
print("Alfabetica:", "12345".isalpha())  #False

# Retornar un valor booleano que indica si la cadena es numerica (numeros)
print("Numerica:", texto.isdigit()) # False no tenemos ningun numero
print("Numerica:", "12345".isdigit()) # True
print("Numerica:", "12 345".isdigit()) # False
print("Numerica:", "12.345".isdigit()) # False

# isdecimal() solo caracteres 0-9 y permite unicode
print("Numerica:", "12345".isdecimal()) # True
print("Numerica:", "12.345".isdecimal()) # False
print("Numerica:", "00011101".isdecimal()) # True

a = "\u0030" #unicode for 0
b = "\u0047" #unicode for G

print(a.isdecimal()) # True
print(b.isdecimal()) # False
print(a.isdigit()) # True

# Retorna un valor booleano indicando si el texto esta en minusculas
print("Minusculas:", texto.islower())  # False por la P de Python
print("Minusculas:", "hola".islower()) # True
print("Minusculas:", "hola12345".islower()) # True
print("Minusculas:", "12345hola".islower()) # True

# Retorna un valor booleano indicando si el texto esta en mayusculas
print("Mayusculas:", texto.isupper())  # False solo la P de Python es mayuscula
print("Mayusculas:", "HOLA".isupper()) # True
print("Mayusculas:", "HOLA12345".isupper()) # True
print("Mayusculas:", "12345HOLA".isupper()) # True

# lstrip -> elimina espacios por la izquierda
# rstrip -> elimina espacios por la derecha
# strip -> elimina espacios izquierda y derecha
ejemplo = "   hola   caracola     "
print(ejemplo.lstrip(), end=".\n")  # Por defecto elimina espacios
print("******hola   caracola     ".lstrip('*'), end=".\n")  # eliminar *

print(ejemplo.rstrip(), end=".\n")
print("******hola   caracola******".rstrip('*'), end=".\n")

print(ejemplo.strip(), end=".\n")
print("******hola   caracola******".strip('*'), end=".\n")

# Longitud de la cadena
print("Longitud:", len(texto))
print("Longitud:", texto.__len__())

# Valor maximo y valor minimo
# En la tabla el orden es: numeros, mayusculas, minusculas
print("Max:", max(texto))  # y
print("Max:", max("aaaAAAAbbBB09"))  # b
print("Max:", max("AAAABB09"))  # B
print("Max:", max("aaabb09"))  #b
print("Max:", max("aaaAAAAbbBB"))  #b

print("Min:", min(texto))  # espacio
print("Min:", min("aaaAAAAbbBB09"))  # 0
print("Min:", min("AAAABB09"))  # 0
print("Min:", min("aaabb09"))  # 0
print("Min:", min("aaaAAAAbbBB"))  # A

for i in range(256):  # La tabla ASCII va desde 0 hasta 255
    print(i, ':', chr(i))

# Reemplazar texto
print("Reemplazar:", "abracadabra".replace('a','A')) # Reemplaza todas
print("Reemplazar:", "abracadabra".replace('a','A', 1))  # Solo la primera
print("Reemplazar:", "abracadabra".replace('a','A', 2))  # Solo las dos primeras
print("Reemplazar:", "abracadabra".replace('a','A', -1)) # AbrAcAdAbrA

# Retornar todas las palabras en una lista
print("lista:", texto.split())
print("lista:", "9/4/2024".split('/'))

# Intercambiar mayusculas por minisculas
print("Swapcase:", "Hola, Que Tal?".swapcase())