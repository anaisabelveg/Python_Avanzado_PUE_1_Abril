# comparaciones

print("20" == 20)  # False
print("20" != 20)  # True
#print("20" >= 20)  # TypeError: '>=' not supported between instances of 'str' and 'int'
#print("20" <= 20)  # TypeError: '<=' not supported between instances of 'str' and 'int'
#print("20" > 20)  # TypeError: '>' not supported between instances of 'str' and 'int'
#print("20" < 20)  #TypeError: '<' not supported between instances of 'str' and 'int'

# operadores de pertenencia in y not in

'''
    count()
    ord()
    chr()
    sort()
    sorted()
    startwith
    endswith
    find y rfind
    join
    isspace
    center
    insert
    append
    filter
'''