for num in range(50):
    print(num)

import time

for num in range(10):
    # parar el hilo 2 segundos
    time.sleep(2)
    print(num)