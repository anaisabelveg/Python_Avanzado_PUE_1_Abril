import os

if os.path.exists("binario.bin"):
    os.remove("binario.bin")