import logging

# Obtener el objeto logger
logger = logging.getLogger()

logger = logging.getLogger('hola')

logger = logging.getLogger('hello.world')

logger = logging.getLogger(__name__)
