"""
    crear una lista con 20 numeros
    mostrar por consola solo los numeros pares
"""

numeros = [4,8,1,9,2,11,15,3,7,18,5,0,21,44,57,91,82,39,43,100]
for num in numeros :
    if (num % 2 == 0):
        print(num)