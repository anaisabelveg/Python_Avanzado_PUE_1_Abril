# encontrar los numeros primos del 1 al 100
# un numero primo solo es divisible por si mismo y la unidad
# p. e. para probar si 7 es primo, recorremos sus posible divisores del 2 al 6

bucle para recorrer los numeros hasta el 100

    bucle para recorrer los posibles divisores
    
    si despues de recorrer todos sigue siendo primo lo mostramos